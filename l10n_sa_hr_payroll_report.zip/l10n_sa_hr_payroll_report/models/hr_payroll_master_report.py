# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import base64
import io
import calendar
from collections import defaultdict
from datetime import datetime

from dateutil.relativedelta import relativedelta

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError, UserError
from odoo.tools.misc import xlsxwriter

XLSX = {
    'NUMBER': 0,
    'TEXT': 1,
    'DATE': 2,
    'FORMULA': 3,
    'LABEL': 4,
}


class HrSaMasterReport(models.Model):
    _name = 'report.l10n_sa_hr_payroll.master'
    _description = 'Saudi Arabia Master Payroll Report'

    name = fields.Char(compute='_compute_name', store=True)
    date_from = fields.Date(required=True, default=fields.Date.today() + relativedelta(day=1))
    date_to = fields.Date(required=True, default=fields.Date.today() + relativedelta(day=1, months=1, days=-1))
    xlsx_file = fields.Binary(string='Report', readonly=True)
    xlsx_filename = fields.Char(readonly=True)
    period_has_payslips = fields.Boolean(compute='_compute_period_has_payslips')

    @api.model
    def default_get(self, field_list=None):
        if self.env.company.country_id.code != 'SA':
            raise UserError(_("You must be logged into a Saudi Arabian company to use this feature."))
        return super().default_get(field_list)

    @api.depends('date_from', 'date_to')
    def _compute_name(self):
        for report in self:
            report.name = _('Master Report %(date_from)s - %(date_to)s',
                           date_from=report.date_from, date_to=report.date_to)

    @api.depends('date_from', 'date_to')
    def _compute_period_has_payslips(self):
        for report in self:
            payslips = report.env['hr.payslip'].search([
                ('date_from', '>=', report.date_from),
                ('date_to', '<=', report.date_to),
                ('company_id', '=', report.env.company.id),
                ('state', 'in', ['done', 'paid'])
            ])
            report.period_has_payslips = bool(payslips)

    @api.constrains('date_from', 'date_to')
    def _check_dates(self):
        for report in self:
            if report.date_from > report.date_to:
                raise ValidationError(_('The starting date must be before or equal to the ending date'))

    @api.model
    def _write_row(self, worksheet, row_index, row, formats):
        for i, (formatting, *value) in enumerate(row):
            if formatting == XLSX['TEXT']:
                worksheet.write(row_index, i, *value, formats[XLSX['TEXT']])
            elif formatting == XLSX['DATE']:
                worksheet.write_datetime(row_index, i, *value, formats[XLSX['DATE']])
            elif formatting == XLSX['NUMBER']:
                worksheet.write_number(row_index, i, *value, formats[XLSX['NUMBER']])

    def _get_month_name(self, date):
        """Return the salary month description in English format: Salary OF [Month][YY]"""
        month_names_en = {
            1: 'Jan',
            2: 'Feb',
            3: 'Mar',
            4: 'Apr',
            5: 'May',
            6: 'Jun',
            7: 'Jul',
            8: 'Aug',
            9: 'Sep',
            10: 'Oct',
            11: 'Nov',
            12: 'Dec'
        }
        month_short = month_names_en.get(date.month, '')
        year_short = date.strftime('%y')
        return f"Salary OF {month_short}{year_short}"

    def action_generate_report(self):
        company = self.env.company
        if company.country_id.code != 'SA':
            raise UserError(_("You must be logged into a Saudi Arabian company to use this feature."))

        labels = [
            _('Net'),
            _('Employee IBAN'),
            _('Employee Name'),
            _('Bank'),
            _('Description'),
            _('Basic'),
            _('Housing'),
            _('Total Other Allownces'),
            _('Total Deductions'),
            _('ID'),
        ]

        output = io.BytesIO()
        workbook = xlsxwriter.Workbook(output)

        formats = {
            XLSX['TEXT']: workbook.add_format({'border': 1}),
            XLSX['DATE']: workbook.add_format({'border': 1, 'num_format': 'dd/mm/yyyy'}),
            XLSX['LABEL']: workbook.add_format({'border': 1, 'bold': True}),
            XLSX['NUMBER']: workbook.add_format({'border': 1, 'num_format': '#,##0.00'}),
        }

        payslips = self.env['hr.payslip'].search([
            ('date_from', '>=', self.date_from),
            ('date_to', '<=', self.date_to),
            ('company_id', '=', company.id),
            ('state', 'in', ['done', 'paid'])
        ])
        
        if not payslips:
            raise ValidationError(_('There are no eligible payslips for that period of time'))
        
        payslips_data = defaultdict(dict)
        for payslip in payslips:
            payslips_data[payslip.struct_id][payslip.employee_id] = payslip

        for struct in payslips_data:
            worksheet = workbook.add_worksheet(name=struct.name)

            for col, label in enumerate(labels):
                worksheet.write(0, col, label, formats[XLSX['LABEL']])

            i = 1
            for employee in payslips_data[struct]:
                payslip = payslips_data[struct][employee]
                
                bank_name = ''
                bank_account = ''
                if employee.bank_account_id:
                    bank_name = employee.bank_account_id.bank_id.name or ''
                    bank_account = employee.bank_account_id.acc_number or ''

                salary_description = self._get_month_name(self.date_from)
                
                net = 0
                basic = 0
                housing = 0
                allowances = 0
                deductions = 0
                
                for line in payslip.line_ids:
                    if line.code == 'NET':
                        net = line.total
                    elif line.code == 'BASIC':
                        basic = line.total
                    elif line.code == 'HRA' or line.code == 'HOUSING':
                        housing = line.total
                    elif line.category_id.code == 'ALW':
                        allowances += line.total
                    elif line.category_id.code == 'DED':
                        deductions += line.total
                
                allowances = max(0, allowances - basic - housing)
                
                row = [
                    (XLSX['NUMBER'], net),
                    (XLSX['TEXT'], bank_account),
                    (XLSX['TEXT'], employee.name),
                    (XLSX['TEXT'], bank_name),
                    (XLSX['TEXT'], salary_description),
                    (XLSX['NUMBER'], basic),
                    (XLSX['NUMBER'], housing),
                    (XLSX['NUMBER'], allowances),
                    (XLSX['NUMBER'], deductions),
                    (XLSX['TEXT'], employee.identification_id or ''),
                ]
                
                self._write_row(worksheet, i, row, formats)
                i += 1

            worksheet.set_column(0, len(labels) - 1, 20)

        workbook.close()
        xlsx_data = output.getvalue()
        self.xlsx_file = base64.encodebytes(xlsx_data)
        self.xlsx_filename = f'{self.name}.xlsx' 